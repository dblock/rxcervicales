/*
	Rx Cervicales - Projet de Recherche sur la Radiologie Cervicales Fonctionnelle
	Travail de Licence, � Univerit� de Gen�ve, 1999, Tous droits reserv�s
	------------------------------------------------------------------------------
	�crit par Daniel Doubrovkine (doubrov5@cuimail.unige.ch / dblock@vestris.com)
	http://cuiwww.unige.ch/~doubrov5/uni/license
	------------------------------------------------------------------------------
	Ce code est du domaine public. Il est distribu� sans aucune garantie.
	*/

#include "stdafx.h"
#include "Rx.h"
#include "ToolBase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

CToolBase::CToolBase() {

}

CToolBase::~CToolBase() {

}
