/*
	Rx Cervicales - Projet de Recherche sur la Radiologie Cervicales Fonctionnelle
	Travail de Licence, � Univerit� de Gen�ve, 1999, Tous droits reserv�s
	------------------------------------------------------------------------------
	�crit par Daniel Doubrovkine (doubrov5@cuimail.unige.ch / dblock@vestris.com)
	http://cuiwww.unige.ch/~doubrov5/uni/license
	------------------------------------------------------------------------------
	Ce code est du domaine public. Il est distribu� sans aucune garantie.
	*/

#ifndef C_TOOL_BASE_H
#define C_TOOL_BASE_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CToolBase {
public:
	CToolBase();
	virtual ~CToolBase();

};

#endif
