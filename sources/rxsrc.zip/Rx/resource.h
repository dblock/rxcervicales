//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Rx.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_RXTYPE                      129
#define IDR_DTOOLS                      130
#define IDD_INIT                        134
#define IDB_BITMAP1                     137
#define IDD_PROGRESS                    150
#define IDD_ATRACE                      151
#define IDD_METRIC                      153
#define IDB_BITMAP_METRIC               155
#define IDC_SYSINFO                     1000
#define IDC_RXVERSION                   1001
#define IDC_PROGRESSBAR                 1003
#define IDC_PROGRESS                    1004
#define IDC_TRACE_TREE                  1005
#define IDC_METRIC_INPUT                1009
#define IDC_QMETRIC                     1010
#define IDC_ATPRINT                     1011
#define IDC_ATR_COPY                    1012
#define ID_DTOOL_LINE                   32771
#define ID_DTOOL_VECTOR                 32772
#define ID_DTOOL_SYM                    32773
#define ID_DTOOL_NODE                   32774
#define ID_DTOOL_TEXT                   32775
#define ID_DTOOL_COLORS                 32776
#define ID_PROP_COLORS                  32778
#define ID_EDIT_COPYTO                  32780
#define ID_EDIT_PASTEFROM               32781
#define ID_EDIT_OSIZE                   32782
#define ID_EDIT_OZERO                   32783
#define ID_VIEW_ZOOMIN                  32784
#define ID_VIEW_ZOOMOUT                 32785
#define ID_DTOOL_FONT                   32786
#define ID_DTOOL_DISTANCE               32788
#define ID_DTOOL_MDIST                  32789
#define ID_TOOLS_ANGLETRACER_DEFINEFLEXION 32790
#define ID_TOOLS_ANGLETRACER_DEFINEEXTENSION 32791
#define ID_TOOLS_ANGLETRACER_TRACEFRONT 32792
#define ID_TOOLS_ANGLETRACER_COMPAREANGLES 32793
#define ID_DTOOL_ROTATE                 32805
#define ID_DTOOL_ALPHA                  32806
#define ID_OPTION_SHOWANGLES            32807
#define ID_OPTION_SHOWROT               32808
#define ID_IMAGES_MODE                  32809
#define ID_IMAGES_MODE_MONOCHROME       32810
#define ID_IMAGES_MODE_GRAYSCALE        32811
#define ID_IMAGES_MODE_LOGARITHMICGRAYSCALE 32812
#define ID_IMAGES_MODE_FLOYDSTEINBERG   32813
#define IDD_HISTOGRAM                   32814
#define ID_IMAGES_INFORMATION           32814
#define ID_IMAGES_TRANSFORM_EQUALIZE    32815
#define ID_IMAGES_TRANSFORM_INVERT      32816
#define ID_IMAGES_TRANSFORM_BLUR        32817
#define ID_IMAGES_TRANSFORM_BLURMORE    32818
#define ID_IMAGES_TRANSFORM_SHARPEN     32819
#define ID_IMAGES_TRANSFORM_SOBELEDGEDETECT 32820
#define ID_IMAGES_TRANSFORM_MEDIANFILTER 32821
#define ID_IMAGES_ADJUSTCONVOLVE_THIN   32822
#define ID_IMAGES_ADJUSTCONVOLVE_ROBERTSEDGEDETECT 32823
#define ID_IMAGES_ADJUSTCONVOLVE_LAPLACIANEDGEDETECT 32824
#define ID_IMAGES_SIZEROTATE            32825
#define ID_IMAGES_SIZEROTATE_FLIPHORIZONTAL 32826
#define ID_IMAGES_SIZEROTATE_FLIPVERTICAL 32827
#define ID_MEDIC_CERVICALESANGLETRACER_ASSISTEDTRACER 32828
#define ID_MEDIC_CERVICALESANGLETRACER_DEFINEFLEXIONVECTOR 32829
#define ID_MEDIC_CERVICALESANGLETRACER_DEFINEEXTENSIONVECTOR 32830
#define ID_DTOOL_ERASE                  32831
#define ID_IMAGES_ADJUSTCONVOLVE_CONTOUR 32832
#define ID_TOOLS_DEFINEMETRIC           32833

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        165
#define _APS_NEXT_COMMAND_VALUE         32836
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
